#ifndef PLAYER_H
#define PLAYER_H

#include "carta.h"


void obterNomeJogador(char *nome, int tamanhoMaximo);

#endif // PLAYER_H
